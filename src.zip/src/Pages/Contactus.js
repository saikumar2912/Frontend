import React from 'react'

const Contactus = () => {
    return (
        <div>
            <h1>contact</h1>

            
        </div>
    )
}

export default Contactus
